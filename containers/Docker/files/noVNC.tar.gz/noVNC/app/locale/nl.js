/*
 * Translations for nl
 *
 * This file was autotomatically generated from nl.po
 * DO NOT EDIT!
 */

Language = {
    "Connecting...": "Verbinden...",
    "Connected (encrypted) to ": "Verbonden (versleuteld) met ",
    "Connected (unencrypted) to ": "Verbonden (onversleuteld) met ",
    "Disconnecting...": "Verbinding verbreken...",
    "Disconnected": "Verbinding verbroken",
    "Must set host and port": "Host en poort moeten worden ingesteld",
    "Password is required": "Wachtwoord is vereist",
    "Forcing clipping mode since scrollbars aren't supported by IE in fullscreen": "''Clipping mode' ingeschakeld, omdat schuifbalken in volledige-scherm-modus in IE niet worden ondersteund",
    "Disconnect timeout": "Timeout tijdens verbreken van verbinding",
};
